
while [[ $op -me 0 ]]; do
    if [[ $(systemctl is-active docker) == "active" ]]; then
        echo "Docker está activo"
        if [[ $(docker-compose ps | grep "up") ]]; then
            echo "docker-compose está ejecutando contenedores"
        else
            echo "docker-compose no está ejecutando contenedores"
        fi
    else
        echo "Docker no está activo"
    fi
    echo "--Menú de Docker-"
    echo "[1] Encender/Apagar Docker y contenedores"
    echo "[2] Salir"
    read -p "Ingrese una opcion: " op
    case $op in
        1)
            if [[ $(systemctl is-active docker) == "active" ]]; then
                echo "Desactivando Docker"
                sudo systemctl stop docker
            else
                echo "Activando docker"
                sudo systemctl start docker
            fi
            ;;
        2)
            menu.sh
            ;;
        *)
            docker.sh
            ;;
    esac
    